// JavaScript Document

var G_PageCount    = 0;      // ��ҳ��
var G_NumPerPage   = 10;     // ÿҳ��ʾ��������Ϣ
var G_CurrentPage  = 1;      // ��ǰ��ʾ�ڼ�ҳ
var G_MsgGroupName = "all";  // ��ǰ��ʾ����Ϣ��
var G_MsgGroup;
var G_MsgList;
var G_SaveLI;

//
function document.onkeydown()
{
	if (event.keyCode == 116)
	{
		event.keyCode = 0;
		event.cancelBubble = true;
		return false;
	}
}

function HTMLEncode(str)
{
	if (str.length == 0) return "";
	
	var s = str.replace(/&/g, "&gt;");
	s = s.replace(/</g, "&lt;");
	s = s.replace(/>/g, "&gt;");
	s = s.replace(/ /g, "&nbsp;");
	s = s.replace(/\'/g, "&#39;");
	s = s.replace(/\"/g, "&quot;");
	s = s.replace(/\n/g, "<br>");
	
	return s;
}

function toggleFrame()
{
	var calendar = document.getElementById("calendar_detail");
	var btn = document.getElementById("boxchange_btn");
	if(calendar.style.display == "block" || calendar.style.display == "")
	{
		calendar.style.display = "none";
		btn.className = "boxchange_btn_right";
		window.resizeTo(230, 320);
		ShowNoMsgContent();
	}
	else 
	{
		calendar.style.display = "block";
		btn.className = "boxchange_btn_left";
		window.resizeTo(540, 320);
	}
}

function openFrame()
{
	var calendar = document.getElementById("calendar_detail");
	var btn = document.getElementById("boxchange_btn");
		
	calendar.style.display = "block";
	btn.className = "boxchange_btn_left";
	window.resizeTo(540, 320);
}

function SelectCheckBox(chkboxName, checked)
{
	var box = document.getElementsByName(chkboxName);
	for (var i = 0; i < box.length; i++)
		box[i].checked = checked;
}

function GenerateGroupHTML(groupName, displayName, displayTitle)
{
	var s = '<span ';
	if (G_MsgGroupName == groupName) s = s + 'class="messagegroup_selected"';
	else                             s = s + 'class="messagegroup_normal"';
	s = s + '><a href="javascript:ShowMessageList(\'' + groupName + '\');" ';
	s = s + 'title="' + displayTitle + '">' + displayName;
	s = s + '</a></span> ';
	return s;
}

function CheckMsgContent()
{
	var MsgId = parseInt(document.getElementById("MsgTitle").MsgId);
	if (isNaN(MsgId) || (MsgId == -1)) return;
	
	var msgItem = G_MsgList.item("MsgId=" + MsgId);
	if (!msgItem) ShowNoMsgContent();
}

function ShowMessagePage(PageIndex)
{
	PageIndex = parseInt(PageIndex);
	if (isNaN(PageIndex)) return;

	var MsgCount = G_MsgList.count;
	G_PageCount = (MsgCount%G_NumPerPage==0)?(MsgCount/G_NumPerPage):(Math.floor(MsgCount/G_NumPerPage)+1);
	if (PageIndex > G_PageCount) PageIndex = G_PageCount;
	if (PageIndex < 1) PageIndex = 1;
	if (MsgCount == 0) PageIndex = 0;
//	var MsgFirstIndex = (PageIndex>0)?(MsgCount - (PageIndex - 1) * G_NumPerPage):0;
//	var MsgLastIndex  = (MsgFirstIndex-G_NumPerPage>0)?(MsgFirstIndex-G_NumPerPage):0;
	var MsgFirstIndex = (PageIndex>0)?((PageIndex-1)*G_NumPerPage):0;
	var MsgLastIndex  = (PageIndex*G_NumPerPage>MsgCount)?PageIndex*G_NumPerPage:MsgCount;
	var MsgHTML = "";
	var PageHTML = "";
	G_SaveLI = null;
	G_CurrentPage = PageIndex;
	CheckMsgContent();
	
//	for(var i = MsgFirstIndex - 1; i >= MsgLastIndex; i--)
	for(var i = MsgFirstIndex; i < MsgLastIndex; i++)
	{
		msgItem = G_MsgList.item(i);
		if (msgItem)
		{
			MsgHTML = MsgHTML + '<li class="activities_list_normal" ';
			MsgHTML = MsgHTML + 'onclick="javascript:ClickMessageItem(this, ' + msgItem.msgId + ');">';
			MsgHTML = MsgHTML + '<p><span><input type="checkbox" id="MsgItem" value="' + msgItem.msgId + '"></span>';
			MsgHTML = MsgHTML + '<span id="msgitemtitle" style="padding-left: 2px;"';
			if (msgItem.unRead) MsgHTML = MsgHTML + 'class="msglist_unread"';
			else                MsgHTML = MsgHTML + 'class="msglist_read"';
			MsgHTML = MsgHTML + '>' + HTMLEncode(msgItem.Title) + '</span>';
			MsgHTML = MsgHTML + '</p></li>';
		}
	}
	
	// ҳ��������ʼ
	PageHTML = '<P style="padding-top: 4px">';
	// ѡ�����
	PageHTML = PageHTML + '<span style="position: absolute; left: 0px; padding-top: 4px; cursor: pointer">';
	PageHTML = PageHTML + '<input type="checkbox" onclick="SelectCheckBox(\'MsgItem\', this.checked);" title="ȫѡ/ȫ��ѡ">';
	PageHTML = PageHTML + '</span>';
	// ��ҳ
	PageHTML = PageHTML + '<span ';
	if (PageIndex <= 1) PageHTML = PageHTML + 'class="firstpage_disable"';
	else                PageHTML = PageHTML + 'class="firstpage_normal" onclick="javascript:ShowMessagePage(1);"';
	PageHTML = PageHTML + ' title="��ҳ">&nbsp;&nbsp;&nbsp;&nbsp;</span> ';
	// ��һҳ
	PageHTML = PageHTML + '<span ';
	if (PageIndex <= 1) PageHTML = PageHTML + 'class="prevpage_disable"';
	else                PageHTML = PageHTML + 'class="prevpage_normal" onclick="javascript:ShowMessagePage(' + (PageIndex - 1) + ');"';
	PageHTML = PageHTML + ' title="��һҳ">&nbsp;&nbsp;&nbsp;&nbsp;</span> ';
	// ��ҳ��
//	PageHTML = PageHTML + '<span> ��</span><span class="pagenumber">' + G_PageCount + '</span><span>ҳ </span>';
//	// ��ǰҳ
//	PageHTML = PageHTML + '<span> ��ǰ��';
//	PageHTML = PageHTML + '<input type="text" id="txtPageIndex" value="' + PageIndex + '" size="2"  onkeypress="javascript:if(event.keyCode==13)ShowMessagePage(this.value);" onmouseover="javascript:this.select();" />'
//	PageHTML = PageHTML + 'ҳ </span> ';
	PageHTML = PageHTML + '&nbsp;&nbsp;<span><input type="text" id="txtPageIndex" value="' + PageIndex + '" size="1"  onkeypress="if(event.keyCode==13)ShowMessagePage(this.value);" onmouseover="this.select();" onselectstart="event.cancelBubble=true;"/></span>'
	PageHTML = PageHTML + '<span>/</span>';
	PageHTML = PageHTML + '<span class="pagenumber">' + G_PageCount + '</span><span>ҳ��</span>';
	PageHTML = PageHTML + '<span>��</span><span class="pagenumber">' + G_MsgList.count + '</span><span>��</span>&nbsp;&nbsp;';
	// ��һҳ
	PageHTML = PageHTML + '<span ';
	if (PageIndex >= G_PageCount) PageHTML = PageHTML + 'class="nextpage_disable"';
	else                PageHTML = PageHTML + 'class="nextpage_normal" onclick="javascript:ShowMessagePage(' + (PageIndex + 1) + ');"';
	PageHTML = PageHTML + ' title="��һҳ">&nbsp;&nbsp;&nbsp;&nbsp;</span> ';
	// ĩҳ
	PageHTML = PageHTML + '<span ';
	if (PageIndex >= G_PageCount) PageHTML = PageHTML + 'class="lastpage_disable"';
	else                PageHTML = PageHTML + 'class="lastpage_normal" onclick="javascript:ShowMessagePage(' + G_PageCount + ');"';
	PageHTML = PageHTML + ' title="ĩҳ">&nbsp;&nbsp;&nbsp;&nbsp;</span> ';
	// ҳ����������
	PageHTML = PageHTML + '</P>';

	// ѡ�������ʼ
	PageHTML = PageHTML + '<P>';
	// ȫ�����Ѷ���δ����Ϣ����
	PageHTML = PageHTML + GenerateGroupHTML("all", "ȫ��", "ȫ����Ϣ");
	PageHTML = PageHTML + GenerateGroupHTML("unread", "δ��", "δ����Ϣ");
	PageHTML = PageHTML + GenerateGroupHTML("read", "�Ѷ�", "�Ѷ���Ϣ");
	// �ָ���
	PageHTML = PageHTML + ' &nbsp;&nbsp;|&nbsp;&nbsp; ';
	// ɾ������
	PageHTML = PageHTML + '<a href="javascript:DeleteMessages(\'MsgItem\');" title="ɾ��ѡ����Ϣ">ɾ��</a> ';
	PageHTML = PageHTML + '<a href="javascript:ClearAllMessages();" title="ɾ��ȫ����Ϣ">ȫ�����</a>';
	// ѡ��������
	PageHTML = PageHTML + "</P>";

	document.getElementById("msglist").innerHTML = MsgHTML;
	document.getElementById("pagenav").innerHTML = PageHTML;
	
	var nmi = document.getElementById("noMessageInfo");
	if (MsgCount > 0)
	  nmi.style.visibility = "hidden"
	else
	{
		var info = "";
		if (G_MsgGroupName == "all")    info = "����ǰû���յ��κ���Ϣ��";
		if (G_MsgGroupName == "unread") info = "��ǰû��δ����Ϣ��";
		if (G_MsgGroupName == "read")   info = "��ǰû���Ѷ���Ϣ��";
		
		nmi.innerText = info;
	    nmi.style.visibility = "visible"
	}
}

function ShowMessageList(groupName)
{
	var group = System.OnlineMessage.Groups.item(groupName);
	if (group && group.Messages)
	{
		G_MsgGroupName = groupName;
		G_MsgGroup = group;
		G_MsgList = G_MsgGroup.Messages;
		ShowMessagePage(1);
	}
}

var G_SaveCheckBox;

function DeleteMessageCallback(BtnNo)
{
	if (BtnNo == 0)
	{
		var MsgId = "";
		for (var i = 0; i < G_SaveCheckBox.length; i++)
		{
			if (G_SaveCheckBox[i].checked)
			{
				MsgId = G_SaveCheckBox[i].value;
				G_MsgGroup.deleteMsgItem("MsgId=" + MsgId);
			}
		}
		// ɾ����ˢ��
		RefreshMessageList();
	}
	G_SaveCheckBox = null;
}

function DeleteMessages(chkboxName)
{
	if (G_MsgList.count == 0)
	{
		System.Content.MsgBox("��ǰû����Ҫɾ������Ϣ��", "ɾ����Ϣ");
		return;
	}

	G_SaveCheckBox = document.getElementsByName(chkboxName);
	var SelNum = 0;
	for (var i = 0; i < G_SaveCheckBox.length; i++)
	{
	  if (G_SaveCheckBox[i].checked) SelNum++;
	}

	if (SelNum == 0)
		System.Content.MsgBox("��û��ѡ���κ���Ϣ��", "ɾ����Ϣ");
	else
		System.Content.MsgBox("��ȷ��Ҫɾ��ѡ�е�" + SelNum + "����Ϣ��\rע�⣺ɾ���󲻿ɻָ���", "ɾ����Ϣ", DeleteMessageCallback);
}

function ClearMessageCallback(BtnNo)
{
	if (BtnNo == 0) 
	{
		G_MsgGroup.deleteAll();
		// ɾ����ˢ��
		RefreshMessageList();
	}
}

function ClearAllMessages()
{
	if (G_MsgList.count == 0)
	{
		System.Content.MsgBox("��ǰû����Ҫɾ������Ϣ��", "�����Ϣ");
		return;
	}
	
	var DispName = "";
	if (G_MsgGroupName == "unread")    DispName = "δ��";
	else if (G_MsgGroupName == "read") DispName = "�Ѷ�";
	
	System.Content.MsgBox("��ȷ��Ҫɾ��ȫ��" + DispName + "��Ϣ��\rע�⣺ɾ���󲻿ɻָ���", "�����Ϣ", ClearMessageCallback);
}

function RefreshMessageList()
{
	ShowMessagePage(G_CurrentPage);
}

function ShowNoMsgContent()
{
	var URLDiv = document.getElementById("URLDiv");
	var TextDiv = document.getElementById("TextDiv");
	var TextContent = document.getElementById("TextContent");
	var MsgTitle = document.getElementById("MsgTitle");

	MsgTitle.innerText       = "";
	MsgTitle.MsgId           = -1;
	URLDiv.style.visibility  = "hidden";
	URLDiv.style.display     = "none";
	URLContent.location.href = "about:blank";
	TextDiv.style.visibility = "hidden";
	TextDiv.style.display    = "none";
	TextContent.innerHTML    = "";
}

function ShowMsgContent(msgItem)
{
	var URLDiv = document.getElementById("URLDiv");
	var TextDiv = document.getElementById("TextDiv");
	var TextContent = document.getElementById("TextContent");
	var MsgTitle = document.getElementById("MsgTitle");

	MsgTitle.innerText = msgItem.Title;
	MsgTitle.MsgId     = msgItem.MsgId;

	switch (msgItem.MsgType)
	{
		case 1:
			URLDiv.style.visibility = "hidden";
			URLDiv.style.display = "none";
			URLContent.location.href = "about:blank";
			TextContent.innerHTML = msgItem.Content;
			TextDiv.style.visibility = "visible";
			TextDiv.style.display = "block";
			break;
		case 2:
			TextDiv.style.visibility = "hidden";
			TextDiv.style.display = "none";
			TextContent.innerHTML = "";
			URLContent.location.href = msgItem.Content;
			URLDiv.style.visibility = "visible";
			URLDiv.style.display = "block";
			break;
		case 3:
			URLDiv.style.visibility = "hidden";
			URLDiv.style.display = "none";
			URLContent.location.href = "about:blank";
			TextContent.innerText = msgItem.Content;
			TextDiv.style.visibility = "visible";
			TextDiv.style.display = "block";
			break;
		default:
			ShowNoMsgContent();
			return false;
	}

	return true;
}

function ClickMessageItem(LI, MsgId)
{
	if (event.srcElement.tagName == "INPUT") return;

	if (!(G_SaveLI && (G_SaveLI == LI)))
	{
		LI.className = "activities_list_hover";
		if(G_SaveLI) G_SaveLI.className = "activities_list_normal";
		G_SaveLI = LI;
	}
	
	msgItem = G_MsgList.item("MsgId=" + MsgId);
	if(!msgItem) return;
	
	if (msgItem.unRead)
	{
		msgItem.unRead = false;
		LI.all("msgitemtitle").className = "msglist_read";
	}
	
	var MsgTitle = document.getElementById("MsgTitle");
	if (MsgTitle.MsgId != msgItem.MsgId)
	{	
		if (ShowMsgContent(msgItem))
			openFrame();
	}

}

function PageLoad()
{
	if (typeof System != "object") return;
	
	window.resizeTo(230, 320);
	window.setTimeout("ShowMessageList(G_MsgGroupName);", 1);
}

function PageUnload()
{
	G_SaveLI   = null;
	G_SaveCheckBox = null;
	G_MsgList  = null;
	G_MsgGroup = null;
}