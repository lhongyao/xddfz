
function btnSetFormCloseOnClick(Sender){
	igwsetdlg.close();
}

function btnCancelOnClick(Sender){
	igwsetdlg.close();
}

function btnThemeNameOnClick(Sender)
{
	PopupMenuUITheme.PopupByWin(btnThemeName);
}

function btnSkinNameOnClick(Sender)
{
	PopupMenuUISkin.PopupByWin(btnSkinName);
}

function VisibleTabControls(iTabIndex, bVisible)
{
	switch(iTabIndex)
	{
		case 0:
			blendcaption.Visible = bVisible;	
			blendvalue.Visible = bVisible;
			sliderBlendValue.Visible = bVisible;
			lblUITheme.Visible = bVisible;
	
			btnThemeName.Visible = bVisible;
			btnThemeDownCombox.Visible = bVisible;
	
			btnSkinName.Visible = false;// bVisible;
			lblUISkin.Visible = false;// bVisible;
			btnSkinDownCombox.Visible = false;// bVisible;
			
			checkboxDisablePopupMsg.Visible =bVisible;
			btnTabUISkin.Enabled = !bVisible;
		break;
		case 1:
			labelsoundRegion.Visible = bVisible;
			lblhintsoundvalueset.Visible = bVisible;
			btnTabAudio.Enabled = !bVisible;
		break;
		case 2:
			checkboxDisablePopupMsg.visible = bVisible;
			checkboxAllowPopupMsg.visible = bVisible;
			labelSystemSetRegion.visible = bVisible;
			btnTabSystemSet.Enabled = !bVisible;
			labelSystemSetScreenCap.visible = false;//bVisible;
		break;
	}
}

function OnbtnTabUISkinClick(Sender)
{
	VisibleTabControls(0, true);
	VisibleTabControls(1, false);
	VisibleTabControls(2, false);
}

function OnbtnTabAudioClick(Sender)
{
	VisibleTabControls(0, false);
	VisibleTabControls(1, true);
	VisibleTabControls(2, false);
}

function OnbtnTabSystemSetClick(Sender)
{
	VisibleTabControls(0, false);
	VisibleTabControls(1, false);
	VisibleTabControls(2, true);
}

OnbtnTabUISkinClick(btnTabUISkin);

//btnSkinName.Visible = false;	
//lblUISkin.Visible = false;
//btnSkinDownCombox.Visible = false;	
