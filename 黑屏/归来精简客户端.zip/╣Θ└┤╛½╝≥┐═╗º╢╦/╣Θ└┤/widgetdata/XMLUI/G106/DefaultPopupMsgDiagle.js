function OnFormResize(Sender)
{
	btnFormClose.left = Sender.width - 25;
	labelcaption.width = Sender.width - 55;
	labelText.width = Sender.width - 30;
	labelText.height = Sender.height - 47;
}

function btnFormCloseOnClick(Sender){
	PopupWidgetMessageDialog.close();
}

OnFormResize(PopupWidgetMessageDialog);
PopupWidgetMessageDialog.onresize="OnFormResize(Self);";