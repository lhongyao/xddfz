function DefaultAdcolumnBarOnResize(Sender){
	// �ı��С���յ�֪ͨ
	btnPageDown.top = Sender.height - 21;
}


DefaultAdcolumnBar.onresize="DefaultAdcolumnBarOnResize(Self);"; 
