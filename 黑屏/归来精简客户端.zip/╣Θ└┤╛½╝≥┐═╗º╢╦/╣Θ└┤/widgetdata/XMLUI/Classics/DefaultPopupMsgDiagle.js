function OnFormResize(Sender)
{
	btnFormClose.left = Sender.width - 20;
	labelcaption.width = Sender.width - 40;
	labelText.width = Sender.width - 30;
	labelText.height = Sender.height - 50;
}

function btnFormCloseOnClick(Sender){
	PopupWidgetMessageDialog.close();
}

OnFormResize(PopupWidgetMessageDialog);
PopupWidgetMessageDialog.onresize="OnFormResize(Self);";