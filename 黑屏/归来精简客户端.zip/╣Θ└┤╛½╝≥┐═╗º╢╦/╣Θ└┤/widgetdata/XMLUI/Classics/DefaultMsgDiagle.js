
function btnFormCloseOnClick(Sender){
	MyTestWidgetDialog.close();
}
