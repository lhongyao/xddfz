function btnigwCapScreenDialogFormCloseClick(Sender)
{
	igwCapScreenDialog.close;
}

function OnigwCapScreenDialogResize(Sender)
{
//	btnigwCapScreenDialogFormClose.left = Sender.width - 20;
	
//	btnSetFullScreen.left = (Sender.width / 2) - 100;	
//	btnSmallScreen.left = (Sender.width / 2) + 30;
	//WidgetAtom.Info.
}

function OnbtnSmallScreenClick(Sender){
	igwCapScreenDialog.ScrCapMini();
}

function OnbtnSetFullScreenClick(Sender){
	if (igwCapScreenDialog.IsCanRestore() == true)
	{
		btnSetFullScreen.SkinName=igwCapScreenDialog.GetCacheSkins("btn_max12x12");
		igwCapScreenDialog.ScrCapRestore();
	}
	else
	{
		btnSetFullScreen.SkinName=igwCapScreenDialog.GetCacheSkins("btn_restore12x12");
		igwCapScreenDialog.ScrCapMax();
	}
}

//OnigwCapScreenDialogResize(igwCapScreenDialog);
//igwCapScreenDialog.onresize="OnigwCapScreenDialogResize(Self);";

function LoadMain(){
	igwCapScreenDialog.AddCacheSkins("btn_max12x12");
	igwCapScreenDialog.AddCacheSkins("btn_restore12x12");
}

LoadMain();